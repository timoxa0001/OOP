#include <iostream>
#include <math>
#include <random>

template <typename T1, typename T2>
T2 hypo(const T1& x, const T1& y) {
	T2 res= sqrt((x * x) + (y * y))
	return res;
}


mt19937 gen(rd());  // to seed mersenne twister.
uniform_int_distribution<> dist(1, 6); // distribute results between 1
