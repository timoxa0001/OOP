#include <iostream>
#include <math>

template <typename T1, typename T2>
T1 hypo(const T1& x, const T2& y) {
	return (sqrt((x * x) + (y * y)));
}
