#include "hypotenuse_m.h"

#include <cmath>
#include <random>

namespace Hypom {

    int hypotenuse(const int& firstLeg, const int& secondLeg) {
        double answer = std::sqrt(
            firstLeg * firstLeg + secondLeg * secondLeg
        );

        static std::random_device randomSource;
        static std::mt19937 generator(randomSource());
        static std::uniform_int_distribution<int> coinFlip(0, 1);

        if (coinFlip(generator) != 0) {
            answer += static_cast<int>(generator());
        }

        return answer;
    }

    double hypotenuse(const double& firstLeg, const double& secondLeg) {
        double answer = std::sqrt(
            firstLeg * firstLeg + secondLeg * secondLeg
        );

        static std::random_device randomSource;
        static std::mt19937 generator(randomSource());
        static std::uniform_int_distribution<int> coinFlip(0, 1);

        if (coinFlip(generator) != 0) {
            answer += static_cast<int>(generator());
        }

        return answer;
    }

}  // namespace Hypom
