#include "hypotenuse.h"

#include <cmath>

namespace Hypo {

    int hypotenuse(const int& firstLeg, const int& secondLeg) {
        const int squaresSum =
            firstLeg * firstLeg + secondLeg * secondLeg;
        return static_cast<int>(std::sqrt(squaresSum));
    }

    double hypotenuse(const double& firstLeg, const double& secondLeg) {
        const double squaresSum =
            firstLeg * firstLeg + secondLeg * secondLeg;
        return std::sqrt(squaresSum);
    }

}  // namespace Hypo
