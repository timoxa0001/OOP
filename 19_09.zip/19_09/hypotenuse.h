#ifndef HYPOTENUSE_H
#define HYPOTENUSE_H

#include <cmath>

namespace Hypo {

    template <class Number>
    Number hypotenuse(const Number& firstLeg, const Number& secondLeg) {
        const Number squaresSum =
            firstLeg * firstLeg + secondLeg * secondLeg;
        return static_cast<Number>(std::sqrt(squaresSum));
    }

    template <class Number>
    void hypotenuse_modify(Number& firstLeg, Number& secondLeg) {
        const Number result = static_cast<Number>(
            std::sqrt(firstLeg * firstLeg + secondLeg * secondLeg)
        );

        firstLeg = result;
        secondLeg = result;
    }

}  // namespace Hypo

#endif  // HYPOTENUSE_H
