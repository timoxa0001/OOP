#include <iostream>
#include "hypotenuse.h"
#include "hypotenuse_m.h"

int main() {
    int firstLeg, secondLeg;
    std::cin >> firstLeg >> secondLeg;

    const int regularIntResult = Hypo::hypotenuse(firstLeg, secondLeg);
    const int randomIntResult = Hypom::hypotenuse(firstLeg, secondLeg);

    std::cout << "Hypo  int: " << regularIntResult << std::endl;
    std::cout << "Hypom int: " << randomIntResult << std::endl;

    double firstDoubleLeg, secondDoubleLeg;
    std::cin >> firstDoubleLeg >> secondDoubleLeg;

    const double regularDoubleResult = Hypo::hypotenuse(firstDoubleLeg, secondDoubleLeg);
    const double randomDoubleResult = Hypom::hypotenuse(firstDoubleLeg, secondDoubleLeg);

    std::cout << "Hypo  double: " << regularDoubleResult << std::endl;
    std::cout << "Hypom double: " << randomDoubleResult << std::endl;

    int x = 3, y = 4;
    std::cout << "Before modify: x = " << x << ", y = " << y << std::endl;
    Hypo::hypotenuse_modify(x, y);
    std::cout << "After  modify: x = " << x << ", y = " << y << std::endl;

    return 0;
}
