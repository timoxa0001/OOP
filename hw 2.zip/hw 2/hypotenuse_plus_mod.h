#ifndef HYPOTENUSE_PLUS_MOD_H
#define HYPOTENUSE_PLUS_MOD_H
#include <cmath>
namespace Hypo {

    template <typename T2, typename T1>
    T2 hypotenuse_plus_mod(T1& a, T1& b) {
        double h = std::sqrt(static_cast<double>(a) * a +
                             static_cast<double>(b) * b);
        a = static_cast<T1>(h);
        b = static_cast<T1>(h);
        return static_cast<T2>(h);
    }

    template <>
    double hypotenuse_plus_mod<double, int>(int& a, int& b);

    template <>
    int hypotenuse_plus_mod<int, double>(double& a, double& b);

}
#endif