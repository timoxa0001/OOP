#include "hypotenuse_plus_mod.h"
#include <cmath>

namespace Hypo {

    // a) int -> double, аргументы int
    template <>
    double hypotenuse_plus_mod<double, int>(int& a, int& b) {
        double h = std::sqrt(static_cast<double>(a) * a +
                             static_cast<double>(b) * b);
        a = static_cast<int>(h);
        b = static_cast<int>(h);
        return h;
    }

    // b) double -> int, аргументы double
    template <>
    int hypotenuse_plus_mod<int, double>(double& a, double& b) {
        double h = std::sqrt(a * a + b * b);
        a = h;
        b = h;
        return static_cast<int>(h);
    }
}