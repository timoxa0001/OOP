#include "hypotenuse_mod.h"
#include <cmath>
#include <random>

namespace Hypo {

    int hypotenuse_mod(const int& a, const int& b) {
        int result = static_cast<int>(std::sqrt(static_cast<double>(a) * a + static_cast<double>(b) * b));
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_int_distribution<int> chance(0, 1);
        if (chance(gen) == 1) result += 1;
        return result;
    }

    double hypotenuse_mod(const double& a, const double& b) {
        double result = std::sqrt(a * a + b * b);
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_int_distribution<int> chance(0, 1);
        if (chance(gen) == 1) result += 1.0;
        return result;
    }
}