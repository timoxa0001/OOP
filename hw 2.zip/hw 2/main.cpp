#include <iostream>
#include "hypotenuse.h"
#include "hypotenuse_mod.h"
#include "hypotenuse_plus.h"
#include "hypotenuse_plus_mod.h"

int main() {

    int a, b;
    std::cin >> a >> b;
    std::cout << "hypotenuse(" << a << ", " << b << ")= " << Hypo::hypotenuse(a, b) << std::endl;
    std::cout << "hypotenuse(" << a << ", " << b << ")= " << Hypo::hypotenuse(a, b) << std::endl;

    double da, db;
    std::cin >> da >> db;
    std::cout << "hypotenuse_mod(" << da << ", " << db << ")  = " << Hypo::hypotenuse_mod(da, db) << std::endl;
    std::cout << "hypotenuse_mod(" << da << ", " << db << ")  = " << Hypo::hypotenuse_mod(da, db) << std::endl;

    int x = 3, y = 4;
    std::cout << "Before mod: x = " << x << ", y = " << y << std::endl;
    Hypo::hypotenuse_mod(x, y);
    std::cout << "After  mod: x = " << x << ", y = " << y << std::endl;

    // hypotenuse_plus
    int ia = 3, ib = 4;

    double r1 = Hypo::hypotenuse_plus<double>(ia, ib);
    std::cout << "plus / int -> double : " << r1 << std::endl;

    float r2 = Hypo::hypotenuse_plus<float>(ia, ib);
    std::cout << "plus / int -> float  : " << r2 << std::endl;

    double dda = 6.0, ddb = 8.0;
    int r3 = Hypo::hypotenuse_plus<int>(dda, ddb);
    std::cout << "plus / double -> int : " << r3 << std::endl;

    // hypotenuse_plus_mod
    int mx = 3, my = 4;
    std::cout << "Before / plus_mod: mx = " << mx << ", my = " << my << std::endl;
    double rm1 = Hypo::hypotenuse_plus_mod<double>(mx, my);
    std::cout << "After / plus_mod: mx = " << mx << ", my = " << my << "  result = " << rm1 << std::endl;

    double mdx = 6.0, mdy = 8.0;
    std::cout << "Before / plus_mod: mdx = " << mdx << ", mdy = " << mdy << std::endl;
    int rm2 = Hypo::hypotenuse_plus_mod<int>(mdx, mdy);
    std::cout << "After / plus_mod: mdx = " << mdx << ", mdy = " << mdy << "  result = " << rm2 << std::endl;

    return 0;
}