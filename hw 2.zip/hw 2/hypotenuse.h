#ifndef HYPOTENUSE_H
#define HYPOTENUSE_H
#include <cmath>

namespace Hypo {

    // базовая
    template <typename T>
    T hypotenuse(const T& a, const T& b) {
        return static_cast<T>(std::sqrt(a * a + b * b));
    }

    // модифицирует a и b, возвращает гипотенузу
    template <typename T>
    T hypotenuse_mod(T& a, T& b) {
        T h = static_cast<T>(std::sqrt(static_cast<double>(a) * a + static_cast<double>(b) * b));
        a = h;
        b = h;
        return h;
    }
}
#endif