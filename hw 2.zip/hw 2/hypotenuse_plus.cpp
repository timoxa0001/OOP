#include "hypotenuse_plus.h"
#include <cmath>
namespace Hypo {

    // int, double
    double hypotenuse_plus(const int& a, const int& b) {
        return std::sqrt(static_cast<double>(a) * a +
                         static_cast<double>(b) * b);
    }

    // double, int
    int hypotenuse_plus(const double& a, const double& b) {
        return static_cast<int>(std::sqrt(a * a + b * b));
    }
}