#ifndef HYPOTENUSE_MOD_H
#define HYPOTENUSE_MOD_H
#include <cmath>
#include <random>

namespace Hypo {

    template <typename T>
    T hypotenuse_mod(const T& a, const T& b) {
        T result = static_cast<T>(std::sqrt(a * a + b * b));
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_int_distribution<int> chance(0, 1);
        if (chance(gen) == 1) result += static_cast<T>(1);
        return result;
    }
}
#endif