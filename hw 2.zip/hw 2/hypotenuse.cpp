#include "hypotenuse.h"
#include <cmath>
namespace Hypo {

    int hypotenuse(const int& a, const int& b) {
        return static_cast<int>(std::sqrt(static_cast<double>(a) * a + static_cast<double>(b) * b));
    }

    double hypotenuse(const double& a, const double& b) {
        return std::sqrt(a * a + b * b);
    }
}