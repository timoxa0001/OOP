#ifndef HYPOTENUSE_PLUS_MOD_H
#define HYPOTENUSE_PLUS_MOD_H

#include <cmath>
#include <random>

namespace Hypo {
  template <typename T2, typename T1>
  T2 hypotenuse_plus_mod(const T1& a, const T1& b) {
    const double x = static_cast<double>(a);
    const double y = static_cast<double>(b);
    double result = std::sqrt(x * x + y * y);

    static std::mt19937 generator(std::random_device{}());
    static std::uniform_int_distribution<int> chance(0, 1);
    static std::uniform_real_distribution<double> addition(0.0, 1.0);

    if (chance(generator) == 1) {
      result += addition(generator);
    }

    return static_cast<T2>(result);
  }
}

#endif
